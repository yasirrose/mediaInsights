<template>
	<div class="card" ref="card">
		<slot />
	</div>
</template>
