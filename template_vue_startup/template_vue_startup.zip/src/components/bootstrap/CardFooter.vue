<template>
	<div class="card-footer">
		<slot />
	</div>
</template>
