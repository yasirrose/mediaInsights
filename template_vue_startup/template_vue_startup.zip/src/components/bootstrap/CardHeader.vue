<template>
	<div class="card-header">
		<slot />
	</div>
</template>
