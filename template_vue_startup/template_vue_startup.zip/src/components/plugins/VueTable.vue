<script>
import VueTableLite from 'vue3-table-lite'

export default {
	components: {
		VueTableLite,
	}
}
</script>

<template>
  <vue-table-lite />
</template>